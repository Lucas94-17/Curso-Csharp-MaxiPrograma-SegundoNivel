﻿namespace negocio
{
    public class Class1
    {

    }
}
